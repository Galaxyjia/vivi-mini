export default {
  navigationBarTitleText: '全部',
  navigationBarBackgroundColor:'#F472B6',
  navigationBarTextStyle:'white'
}
