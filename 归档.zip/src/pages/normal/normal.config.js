export default {
  navigationBarTitleText: '普通',
  navigationBarBackgroundColor:'#F472B6',
  navigationBarTextStyle:'white'
}
