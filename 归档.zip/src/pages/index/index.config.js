export default {
  navigationBarTitleText: '首页',
  navigationBarBackgroundColor:'#F472B6',
  navigationBarTextStyle:'white'
}
