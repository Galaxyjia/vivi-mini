export default {
  navigationBarTitleText: '豪华版',
  navigationBarBackgroundColor:'#F472B6',
  navigationBarTextStyle:'white'
}
