export default {
  navigationBarTitleText: 'Block'
}
