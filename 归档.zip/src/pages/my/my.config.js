export default {
  navigationBarTitleText: '我的',
  navigationBarBackgroundColor:'#F472B6',
  navigationBarTextStyle:'white'
}
