export default {
  navigationBarTitleText: '详情',
  navigationBarBackgroundColor:'#F472B6',
  navigationBarTextStyle:'white'
}
